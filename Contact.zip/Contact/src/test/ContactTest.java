package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import ContactServices.Contact;


class ContactTest {

	@Test
	void testContact() {
		Contact C1 = new Contact("1234");
		assertTrue(C1.getID().equals("1234"));
		Assertions.assertThrows(NullPointerException.class, () -> {new Contact(null);});
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("123213213211");});
	}


	@Test
	void testSetFirstName() {
		Contact C1 = new Contact("1234");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {C1.setFirstName("10987654321");});
		Assertions.assertThrows(NullPointerException.class, () -> {C1.setFirstName(null);});

	}

	@Test
	void testSetLastName() {
		Contact C1 = new Contact("1234");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {C1.setLastName("wadadfdafdsfda");});
		Assertions.assertThrows(NullPointerException.class, () -> {C1.setLastName(null);});

	}

	@Test
	void testSetNumber() {
		Contact C1 = new Contact("1234");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {C1.setNumber("12345678910");});
		Assertions.assertThrows(NullPointerException.class, () -> {C1.setNumber(null);});

	}

	@Test
	void testSetAddress() {
		Contact C1 = new Contact("1234");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {C1.setAddress("1111111111111111111111111111111");});
		Assertions.assertThrows(NullPointerException.class, () -> {C1.setAddress(null);});

	}

}
