package ContactServices;


public class Contact {
	
	private String contactId;
	private String firstName;
	private String lastName;
	private String phoneNum;
	private String address;
	

	//Constructor that will ensure that contact id is properly formatted
	public Contact(String contactId){
		if (contactId.length() > 10 ) {
			throw new IllegalArgumentException("Fomatting incorrect: Length cannot exceed 10");	
		}
		else if(contactId.equals(null)) {
			throw new NullPointerException("Fomatting incorrect: Id cannot be empty");
		}
		else {
			this.contactId = contactId;
			
		}
	
	}
	
	//getters for all private variables	
	public String getID(){
		return contactId;
	}
	
	public String getFirstName(){
		return firstName;
	}
	
	public String getLastName(){
		return lastName;
	}
	
	public String getPhoneNum(){
		return phoneNum;
	}
	
	public String getAddress(){
		return address;
	}
	
	
	//setters for all private variables
	
	public String setFirstName(String name) {
		//Statements will catch any mistakes phone number
		if (name.equals(null)){
			//Exception will be thrown if wrong input is given
			throw new NullPointerException("Field cannot be empty.");
		}
		else if (name.length() > 10){
			//Exception will be thrown if wrong input is given
			throw new IllegalArgumentException("Invalid length.");
		}
		else{
			this.firstName = name;
			return this.firstName;
		}
		
	}	
	
	public String setLastName(String name) {
		//Statements will catch any mistakes
		if (name.equals(null)){
			//Exception will be thrown if wrong input is given
			throw new NullPointerException("Field cannot be empty.");
		}
		else if (name.length() > 10){
			//Exception will be thrown if wrong input is given
			throw new IllegalArgumentException("Invalid length.");
		}
		else{
			this.lastName = name;	
			return this.lastName;
		}
	}
	
	public String setNumber(String number) {
		//Statements will catch any mistakes phone number
		if (number == null){
			//Exception will be thrown if wrong input is given
			throw new NullPointerException("Field cannot be empty.");
		}
		else if (number.length() != 10){
			//Exception will be thrown if wrong input is given
			throw new IllegalArgumentException("Invalid length.");
		}
		else{
			this.phoneNum = number;
			return this.phoneNum;
		}
	}
	
	public String setAddress(String addy) {
		//Statements will catch any mistakes 
		if (addy == null){
			//Exception will be thrown if wrong input is given
			throw new NullPointerException("Field cannot be empty.");
		}
		else if (addy.length() > 30 ){
			//Exception will be thrown if wrong input is given
			throw new IllegalArgumentException("Invalid length.");
		}
		else{
			this.address = addy;
			return this.address;
		}
	}
	
}
