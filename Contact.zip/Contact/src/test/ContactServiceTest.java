package test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import ContactServices.ContactServices;

class ContactServiceTest {

	@Test
	void testAddContact() {
		//Ensures it will only allow unique contact ids
		ContactServices cs1 = new ContactServices();
		cs1.addContact("1234");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {cs1.addContact("1234");});
		
	}

	@Test
	void testRemoveContact() {
		ContactServices cs1 = new ContactServices();
		cs1.addContact("1234");
		cs1.addContact("12345");
		cs1.addContact("123456");
		cs1.removeContact("1234");
		for(int i = 0; i < cs1.contactList.size(); ++i) {
			System.out.println(cs1.contactList.get(i).getID());
		}
		
		
		
	}

	@Test
	void testAddFirstName() {
		ContactServices cs1 = new ContactServices();
		cs1.addContact("1234");
		cs1.addFirstName("1234", "David");
		assertTrue(cs1.contactList.get(0).getFirstName() == "David");
	}

	@Test
	void testAddLastName() {
		ContactServices cs1 = new ContactServices();
		cs1.addContact("1234");
		cs1.addLastName("1234", "Waid");
		assertTrue(cs1.contactList.get(0).getLastName() == "Waid");
	}

	@Test
	void testAddNumber() {
		ContactServices cs1 = new ContactServices();
		cs1.addContact("1234");
		cs1.addNumber("1234", "2105940201");
		assertTrue(cs1.contactList.get(0).getPhoneNum() == "2105940201");
	}

	@Test
	void testAddAdress() {
		ContactServices cs1 = new ContactServices();
		cs1.addContact("1234");
		cs1.addAdress("1234", "7800 superman lane");
		assertTrue(cs1.contactList.get(0).getAddress() == "7800 superman lane");
	}

}
