package ContactServices;
import java.util.ArrayList;
import java.util.List;

public class ContactServices{
	
	
	//todo: create list to hold contacts, make delete contact feature, make feature to update all contact variables
	
	//List to hold uniqure contact ids
	public List<Contact> contactList = new ArrayList<>();
	
	
	
	
	
	public void addContact(String id) {
		//make unique id randomizer
		//This loop will check to make sure this id is unique
		for(int i = 0; i < contactList.size();++i) {
			//if a duplicate the loop will quit and throw exception
			if(contactList.get(i).getID().equals(id)) {
				throw new IllegalArgumentException("Duplicate ID"); 
				}
			}
		contactList.add(new Contact(id));
	}
	
	public void removeContact(String id) {
		
		
		for(int i = 0; i < contactList.size();++i) {
			if(contactList.get(i).getID().equals(id)) {
				contactList.remove(i);
				return;
			}
		}
		
	}
	
	
	
	public void addFirstName(String id, String name) {
		//Find the id and set the first name 
		for(int i = 0; i < contactList.size();++i) {
			if(contactList.get(i).getID().equals(id)) {
				contactList.get(i).setFirstName(name);
			}
			
		}	
	}
	
	public void addLastName(String id, String name) {
		//Find the id and set the last name 
		for(int i = 0; i < contactList.size();++i) {
			if(contactList.get(i).getID().equals(id)) {
				contactList.get(i).setLastName(name);
			}
			
			
		}	
	}
	public void addNumber(String id, String number) {
		//Find the id and set the number 
		for(int i = 0; i < contactList.size();++i) {
			if(contactList.get(i).getID().equals(id)) {
				contactList.get(i).setNumber(number);
		}
					
					
				}	
	}
	public void addAdress(String id,String address) {
		//Find the id and set the address 
		for(int i = 0; i < contactList.size();++i) {
			if(contactList.get(i).getID().equals(id)) {
				contactList.get(i).setAddress(address);
			}
							
		}
	}

}
